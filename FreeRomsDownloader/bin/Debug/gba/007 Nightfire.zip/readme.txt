Sorry the ROM you downloaded is no longer available.  
If you see a download counter or Direct Link on the site it means the ROM is available.

Visit http://www.freeroms.com for other great titles.

